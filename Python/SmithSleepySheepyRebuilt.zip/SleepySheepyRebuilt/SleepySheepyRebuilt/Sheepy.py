import pygame
import random as r
import math as m
import QuickMaths
from pygame import *
from random import *
from math import *
from QuickMaths import *

class Sheepy(object):
	"""description of class"""
	CONST_SHEEP_LENGTH = 20
	CONST_SHEEP_SPRING = .9
	CONST_SHEEP_MIN = 2 * CONST_SHEEP_LENGTH
	CONST_SHEEP_MAX = 5 * CONST_SHEEP_LENGTH
	CONST_SHEEP_NEIGHBOR_RANGE = 120

	def __init__(self, screen, pos, vel):
		self.name = ""
		spr = pygame.image.load("Circle.png")
		self.original_Sprite = spr.convert_alpha()
		self.position = pos
		self.screen = screen
		self.orientation = 0
		self.velocity = QuickMaths.getNormalized(vel)
		self.initVel = (self.velocity[0], self.velocity[1])
		self.maxLinVel = r.uniform(5, 25)

	def draw(self):
		self.drawRect = pygame.Rect(self.position[0], self.position[1], self.original_Sprite.get_width(), self.original_Sprite.get_height())
		self.sprite = pygame.transform.rotate(self.original_Sprite, self.orientation)
		x,y = self.drawRect.center
		self.drawRect = self.sprite.get_rect()
		self.drawRect.center = (x,y)
		self.screen.blit(self.sprite, (self.position[0], self.position[1]))
		pygame.draw.line(self.screen, (255,0,0), self.drawRect.center, (self.drawRect.center[0] + self.velocity[0] * self.maxLinVel, self.drawRect.center[1] +  self.velocity[1] * self.maxLinVel), 2)
		pygame.draw.circle(self.screen,(0,255, 255), (int(self.drawRect.center[0]), int(self.drawRect.center[1])), Sheepy.CONST_SHEEP_NEIGHBOR_RANGE, 2)

	def update(self, step, sheepList):
		self.rotateVelocity(r.uniform(-3,3))
		self.velocity = QuickMaths.getNormalized(QuickMaths.addTuples(QuickMaths.addTuples(self.computeAlignment(step, sheepList), self.computeCohesion(step, sheepList)), self.computeSeparation(step, sheepList)))
		self.position = QuickMaths.addTuples(self.position, QuickMaths.getScaled(self.velocity, self.maxLinVel * step))

	def rotateVelocity(self, angle):
		valX = self.velocity[0]
		valY = self.velocity[1]
		valAng = m.radians(angle)
		self.velocity = (valX * m.cos(valAng) - valY * m.sin(valAng), valX * m.sin(valAng) + valY * m.cos(valAng))

	def getDistToSheep(self, sheep):
		return m.sqrt((self.position[0] - sheep.position[0])**2 + (self.position[1] - sheep.position[1])**2)

	def computeAlignment(self, step, sheepList):
		closeSheep = []
		netAlignment = self.velocity
		for sheep in sheepList:
			if (sheep != self and self.getDistToSheep(sheep) < Sheepy.CONST_SHEEP_NEIGHBOR_RANGE/2):
				netAlignment = QuickMaths.addTuples(netAlignment, sheep.velocity)
				closeSheep.append(sheep)
		if (len(closeSheep) == 0):
			return QuickMaths.getNormalized(netAlignment)
		else:
			return QuickMaths.getNormalized(QuickMaths.getScaled(netAlignment,1/len(closeSheep)))

	def computeCohesion(self, step, sheepList):
		closeSheep = []
		netMass = self.position
		for sheep in sheepList:
			if (sheep != self and self.getDistToSheep(sheep) < Sheepy.CONST_SHEEP_NEIGHBOR_RANGE):
				netMass = QuickMaths.addTuples(netMass, sheep.position)
				closeSheep.append(sheep)
		if (len(closeSheep) == 0):
			return QuickMaths.getNormalized(netMass)
		else:
			return QuickMaths.getNormalized(QuickMaths.subTuples(QuickMaths.getScaled(netMass, 1/len(closeSheep)), self.position))

	def computeSeparation(self, step, sheepList):
		closeSheep = []
		netSeparation = (0,0)
		for sheep in sheepList:
			if (sheep != self and self.getDistToSheep(sheep) < Sheepy.CONST_SHEEP_NEIGHBOR_RANGE/3):
				netSeparation = QuickMaths.addTuples(netSeparation, QuickMaths.subTuples(sheep.position, self.position))
				closeSheep.append(sheep)
		if (len(closeSheep) == 0):
			return netSeparation
		else:
			return QuickMaths.getNormalized(QuickMaths.getScaled(QuickMaths.getScaled(netSeparation, -1), 1/len(closeSheep)))