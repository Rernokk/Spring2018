import pygame
import Sheepy
import random as r
from pygame import *
from Sheepy import *
from random import *

pygame.init()
screen = pygame.display.set_mode((800,600))

#Initializers
Sheep = [Sheepy(screen,(400,300), (1,0))]
indexer = 1
while (indexer <= 5):
	Sheep.append(Sheepy(screen, (400 + r.uniform(-200, 200), 300 + r.uniform(-150,150)), (0, r.uniform(0,1))))
	indexer += 1

#Game Loop
done = False
clock = time.Clock()
while (not done):
	clock.tick(144)
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			done = True
	for sheep in Sheep:
		sheep.update(clock.get_time() * .001, Sheep)
		sheep.computeAlignment(clock.get_time()*.001, Sheep)
	screen.fill((100,149,237))
	for sheep in Sheep:
		sheep.draw()
	pygame.display.flip()